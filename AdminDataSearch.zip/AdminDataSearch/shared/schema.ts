import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User (can be either admin or staff)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("staff"), // "admin" or "staff"
  name: text("name"),
  email: text("email"),
  position: text("position"),
  staffId: text("staff_id").unique(), // Only used for staff members
  lastActive: timestamp("last_active", { mode: 'date' }),
  active: boolean("active").default(true),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
  name: true,
  email: true,
  position: true,
  staffId: true,
  active: true,
});

// Customer data (can be searched by staff)
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  username: text("username").unique(),
  phoneNumber: text("phone_number"),
  telegram: text("telegram"),
  status: text("status").default("active"),
  addedBy: integer("added_by").references(() => users.id),
  addedAt: timestamp("added_at", { mode: 'date' }),
});

export const insertCustomerSchema = createInsertSchema(customers).pick({
  username: true,
  phoneNumber: true,
  telegram: true,
  status: true,
  addedBy: true,
});

// Activity log
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  action: text("action").notNull(), // "login", "search", "upload", etc.
  details: text("details"),
  searchQuery: text("search_query"), // Specific for search operations
  searchResult: text("search_result"), // "found" or "not_found"
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp", { mode: 'date' }).defaultNow(),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).pick({
  userId: true,
  action: true,
  details: true,
  searchQuery: true,
  searchResult: true,
  ipAddress: true,
  userAgent: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;

// Extended schema for customer search
export const customerSearchSchema = z.object({
  query: z.string().min(1, "Search query is required"),
});

export type CustomerSearch = z.infer<typeof customerSearchSchema>;

// Extended schema for staff creation
export const createStaffSchema = insertUserSchema.extend({
  password: z.string().optional(), // Password will be generated
});
