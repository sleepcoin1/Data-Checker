import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { customerSearchSchema, insertCustomerSchema } from "@shared/schema";
import { setupAuth } from "./auth";
import multer from "multer";
import { parse } from "csv-parse";

// Set up file upload with multer (in-memory storage)
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  }
});

// Check if user is authenticated
function isAuthenticated(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

// Check if user is admin
function isAdmin(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated() && req.user.role === "admin") {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Admin access required" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // CUSTOMER DATA ROUTES (Admin only)
  
  // Get all customers (paginated)
  app.get("/api/customers", isAdmin, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const customers = await storage.listCustomers(limit, offset);
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  // Upload customer data (CSV/TXT)
  app.post("/api/customers/upload", isAdmin, upload.single("file"), async (req, res) => {
    try {
      console.log("Upload request received:", req.file, req.body);
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const fileBuffer = req.file.buffer;
      const fileContent = fileBuffer.toString();
      
      console.log("File content:", fileContent);
      
      // Process the file - simple approach for all formats
      const lines = fileContent.split(/\r?\n/).filter(line => line.trim().length > 0);
      
      if (lines.length === 0) {
        return res.status(400).json({ message: "File is empty" });
      }
      
      // Create phone number records
      const customers = lines.map(line => ({
        phoneNumber: line.trim(),
        username: null,
        telegram: null,
        status: "active",
        addedBy: req.user.id
      }));
      
      console.log("Customer records created:", customers);
      
      // Filter out any invalid records
      const validCustomers = customers.filter(c => c.phoneNumber && c.phoneNumber.length > 0);
      
      if (validCustomers.length === 0) {
        console.log("No valid customers found");
        return res.status(400).json({ message: "No valid customer data found in file" });
      }
      
      // Save to database
      const addedCustomers = await storage.createManyCustomers(validCustomers);
      
      // Log the activity
      await storage.createActivityLog({
        userId: req.user.id,
        action: "upload_customers",
        details: `Uploaded ${addedCustomers.length} customers`,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent') || 'Unknown',
      });
      
      // Return success response
      res.status(201).json({ 
        message: `Successfully uploaded ${addedCustomers.length} customers`,
        count: addedCustomers.length 
      });
    } catch (error) {
      console.error("File upload error:", error);
      res.status(500).json({ message: "Failed to upload file" });
    }
  });

  // STAFF MANAGEMENT ROUTES (Admin only)
  
  // Get all staff members
  app.get("/api/staff", isAdmin, async (req, res) => {
    try {
      const staffMembers = await storage.listUsers("staff");
      
      // Remove passwords from response
      const staffWithoutPasswords = staffMembers.map(staff => {
        const { password, ...staffWithoutPassword } = staff;
        return staffWithoutPassword;
      });
      
      res.json(staffWithoutPasswords);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch staff members" });
    }
  });

  // SEARCH ROUTES (Both admin and staff)
  
  // Search for a customer
  app.post("/api/search", isAuthenticated, async (req, res) => {
    try {
      const { query } = customerSearchSchema.parse(req.body);
      
      // Search for customer
      const customer = await storage.getCustomerByIdentifier(query);
      
      // Log the search activity
      await storage.createActivityLog({
        userId: req.user.id,
        action: "search",
        searchQuery: query,
        searchResult: customer ? "found" : "not_found",
        details: `User searched for "${query}"`,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent') || 'Unknown',
      });
      
      // Only return found/not found result (not the actual data for staff)
      if (req.user.role === "staff") {
        return res.json({ found: !!customer });
      }
      
      // For admin, return the full customer data if found
      return res.json({ 
        found: !!customer,
        customer: customer
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid search query" });
    }
  });

  // ACTIVITY LOG ROUTES (Admin only)
  
  // Get activity logs
  app.get("/api/activity-logs", isAdmin, async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const action = req.query.action as string | undefined;
      const limit = parseInt(req.query.limit as string) || 100;
      
      const logs = await storage.listActivityLogs(userId, action, limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activity logs" });
    }
  });

  // Get recent searches for the current user
  app.get("/api/recent-searches", isAuthenticated, async (req, res) => {
    try {
      const logs = await storage.listActivityLogs(
        req.user.id, 
        "search", 
        10
      );
      
      // Transform logs to a more convenient format
      const searches = logs.map(log => ({
        id: log.id,
        query: log.searchQuery,
        result: log.searchResult,
        timestamp: log.timestamp
      }));
      
      res.json(searches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent searches" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}