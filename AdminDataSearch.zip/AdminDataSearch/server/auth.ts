import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  // Check if stored password has the correct format
  if (!stored || !stored.includes(".")) {
    // If the admin password wasn't hashed properly, let's handle a direct comparison
    // This is only for the initial admin account
    if (supplied === stored && supplied === "admin123") {
      return true;
    }
    return false;
  }
  
  const [hashed, salt] = stored.split(".");
  if (!hashed || !salt) {
    console.error("Invalid password format in database");
    return false;
  }
  
  try {
    const hashedBuf = Buffer.from(hashed, "hex");
    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    return timingSafeEqual(hashedBuf, suppliedBuf);
  } catch (error) {
    console.error("Error comparing passwords:", error);
    return false;
  }
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "customer-verification-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 1000 * 60 * 60 * 24, // 24 hours
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false, { message: "Invalid username or password" });
        }
        
        // Update user's last active timestamp
        await storage.updateUser(user.id, { lastActive: new Date() });
        
        // Log successful login
        await storage.createActivityLog({
          userId: user.id,
          action: "login",
          details: `User ${user.username} logged in successfully`,
          ipAddress: "127.0.0.1", // In a real app, get from request
          userAgent: "Unknown", // In a real app, get from request
        });
        
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Register endpoint - only for admins
  app.post("/api/register", async (req, res, next) => {
    try {
      // Only allow authenticated admins to create new users
      if (!req.isAuthenticated() || req.user.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized: Only admins can register new users" });
      }
      
      const { username, password, role } = req.body;
      
      // Validate required fields
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create the new user with hashed password
      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword,
      });

      // Log the user creation
      await storage.createActivityLog({
        userId: req.user.id,
        action: "create_user",
        details: `Admin created a new ${role || 'staff'} account for ${username}`,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent') || 'Unknown',
      });

      // Return the created user (without password)
      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }
      req.login(user, (loginErr) => {
        if (loginErr) {
          return next(loginErr);
        }
        
        // Don't send password back to client
        const { password, ...userWithoutPassword } = user;
        return res.status(200).json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    if (req.isAuthenticated()) {
      const userId = req.user.id;
      const username = req.user.username;
      
      // Log the logout
      storage.createActivityLog({
        userId,
        action: "logout",
        details: `User ${username} logged out`,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent') || 'Unknown',
      }).catch(console.error);
      
      req.logout((err) => {
        if (err) return next(err);
        res.sendStatus(200);
      });
    } else {
      res.sendStatus(200); // Already logged out
    }
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    
    // Don't send password back to client
    const { password, ...userWithoutPassword } = req.user;
    res.json(userWithoutPassword);
  });

  // Create initial admin if not exists
  (async () => {
    try {
      const adminExists = await storage.getUserByUsername("admin");
      if (!adminExists) {
        const hashedPassword = await hashPassword("admin123");
        await storage.createUser({
          username: "admin",
          password: hashedPassword,
          role: "admin",
          name: "Admin User",
          email: "admin@example.com",
          active: true,
        });
        console.log("Created default admin user (username: admin, password: admin123)");
      }
    } catch (error) {
      console.error("Error creating default admin:", error);
    }
  })();
}
