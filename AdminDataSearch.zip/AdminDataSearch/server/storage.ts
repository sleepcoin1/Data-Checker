import { users, type User, type InsertUser, customers, type Customer, type InsertCustomer, activityLogs, type ActivityLog, type InsertActivityLog } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db } from "./db";
import { eq } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  listUsers(role?: string): Promise<User[]>;
  
  // Customer operations
  getCustomer(id: number): Promise<Customer | undefined>;
  getCustomerByIdentifier(identifier: string): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  createManyCustomers(customers: InsertCustomer[]): Promise<Customer[]>;
  listCustomers(limit?: number, offset?: number): Promise<Customer[]>;
  
  // Activity log operations
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  listActivityLogs(userId?: number, action?: string, limit?: number): Promise<ActivityLog[]>;
  
  // Session store
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private customers: Map<number, Customer>;
  private activityLogs: Map<number, ActivityLog>;
  sessionStore: session.SessionStore;
  private userIdCounter: number;
  private customerIdCounter: number;
  private activityLogIdCounter: number;

  constructor() {
    this.users = new Map();
    this.customers = new Map();
    this.activityLogs = new Map();
    this.userIdCounter = 1;
    this.customerIdCounter = 1;
    this.activityLogIdCounter = 1;
    
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    
    // Generate staff ID if role is staff and staffId is not provided
    let staffId = insertUser.staffId;
    if (insertUser.role === "staff" && !staffId) {
      staffId = `S-${1000 + id}`;
    }
    
    const user: User = { 
      ...insertUser, 
      id,
      staffId,
      lastActive: now
    };
    
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async listUsers(role?: string): Promise<User[]> {
    const allUsers = Array.from(this.users.values());
    if (role) {
      return allUsers.filter(user => user.role === role);
    }
    return allUsers;
  }

  // Customer operations
  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customers.get(id);
  }

  async getCustomerByIdentifier(identifier: string): Promise<Customer | undefined> {
    // Clean up identifier (remove spaces, lowercase, etc.)
    const cleanIdentifier = identifier.trim().toLowerCase();
    
    return Array.from(this.customers.values()).find(
      (customer) => 
        (customer.username && customer.username.toLowerCase() === cleanIdentifier) ||
        (customer.phoneNumber && customer.phoneNumber.replace(/\s+/g, '') === cleanIdentifier.replace(/\s+/g, '')) ||
        (customer.telegram && customer.telegram.toLowerCase() === cleanIdentifier)
    );
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = this.customerIdCounter++;
    const now = new Date();
    
    const customer: Customer = { 
      ...insertCustomer, 
      id,
      addedAt: now
    };
    
    this.customers.set(id, customer);
    return customer;
  }

  async createManyCustomers(insertCustomers: InsertCustomer[]): Promise<Customer[]> {
    return Promise.all(insertCustomers.map(customer => this.createCustomer(customer)));
  }

  async listCustomers(limit: number = 100, offset: number = 0): Promise<Customer[]> {
    const allCustomers = Array.from(this.customers.values());
    return allCustomers.slice(offset, offset + limit);
  }

  // Activity log operations
  async createActivityLog(insertLog: InsertActivityLog): Promise<ActivityLog> {
    const id = this.activityLogIdCounter++;
    const now = new Date();
    
    const log: ActivityLog = { 
      ...insertLog, 
      id,
      timestamp: now
    };
    
    this.activityLogs.set(id, log);
    return log;
  }

  async listActivityLogs(userId?: number, action?: string, limit: number = 100): Promise<ActivityLog[]> {
    let allLogs = Array.from(this.activityLogs.values());
    
    // Sort logs by timestamp (newest first)
    allLogs = allLogs.sort((a, b) => {
      return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
    });
    
    // Filter by userId if provided
    if (userId !== undefined) {
      allLogs = allLogs.filter(log => log.userId === userId);
    }
    
    // Filter by action if provided
    if (action) {
      allLogs = allLogs.filter(log => log.action === action);
    }
    
    return allLogs.slice(0, limit);
  }
}

// Import the DatabaseStorage
import { DatabaseStorage } from "./database-storage";

// Use DatabaseStorage for PostgreSQL
export const storage = new DatabaseStorage();
