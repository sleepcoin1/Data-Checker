import { 
  users, type User, type InsertUser, 
  customers, type Customer, type InsertCustomer, 
  activityLogs, type ActivityLog, type InsertActivityLog 
} from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db } from "./db";
import { eq, desc, and, like, sql } from "drizzle-orm";
import { IStorage } from "./storage";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true,
      tableName: "sessions"
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username.toLowerCase()));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Generate staff ID if role is staff and staffId is not provided
    let staffId = insertUser.staffId;
    if (insertUser.role === "staff" && !staffId) {
      // Get latest user id to create staff ID
      const users = await db.query.users.findMany({
        orderBy: (users, { desc }) => [desc(users.id)],
        limit: 1
      });
      const nextId = users.length > 0 ? users[0].id + 1 : 1;
      staffId = `S-${1000 + nextId}`;
    }

    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        staffId,
        lastActive: new Date(),
      })
      .returning();
    
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({
        ...updates,
        // Set lastActive if updating active status
        ...(updates.active !== undefined && { lastActive: new Date() })
      })
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }

  async listUsers(role?: string): Promise<User[]> {
    if (role) {
      return db.select().from(users).where(eq(users.role, role));
    }
    return db.select().from(users);
  }

  // Customer operations
  async getCustomer(id: number): Promise<Customer | undefined> {
    const [customer] = await db
      .select()
      .from(customers)
      .where(eq(customers.id, id));
    
    return customer;
  }

  async getCustomerByIdentifier(identifier: string): Promise<Customer | undefined> {
    // Clean up identifier (remove spaces, lowercase, etc.)
    const cleanIdentifier = identifier.trim().toLowerCase();
    
    // Search for username match
    const usernameMatches = await db
      .select()
      .from(customers)
      .where(
        and(
          eq(customers.status, 'active'),
          sql`lower(${customers.username}) = ${cleanIdentifier}`
        )
      );
    
    if (usernameMatches.length > 0) {
      return usernameMatches[0];
    }
    
    // Search for phone number match (removing spaces)
    const phoneMatches = await db
      .select()
      .from(customers)
      .where(
        and(
          eq(customers.status, 'active'),
          sql`lower(replace(${customers.phoneNumber}, ' ', '')) = ${cleanIdentifier.replace(/\s+/g, '')}`
        )
      );
    
    if (phoneMatches.length > 0) {
      return phoneMatches[0];
    }
    
    // Search for telegram match
    const telegramMatches = await db
      .select()
      .from(customers)
      .where(
        and(
          eq(customers.status, 'active'),
          sql`lower(${customers.telegram}) = ${cleanIdentifier}`
        )
      );
    
    if (telegramMatches.length > 0) {
      return telegramMatches[0];
    }
    
    return undefined;
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const [customer] = await db
      .insert(customers)
      .values({
        ...insertCustomer,
        addedAt: new Date()
      })
      .returning();
    
    return customer;
  }

  async createManyCustomers(insertCustomers: InsertCustomer[]): Promise<Customer[]> {
    // Since we need to ensure addedAt is set for all, 
    // and db.insert() doesn't support batch returning,
    // we'll use Promise.all to insert multiple customers
    return Promise.all(insertCustomers.map(customer => this.createCustomer(customer)));
  }

  async listCustomers(limit: number = 100, offset: number = 0): Promise<Customer[]> {
    return db
      .select()
      .from(customers)
      .where(
        // Exclude deleted customers
        sql`${customers.status} != 'deleted' OR ${customers.status} IS NULL`
      )
      .limit(limit)
      .offset(offset);
  }

  // Activity log operations
  async createActivityLog(insertLog: InsertActivityLog): Promise<ActivityLog> {
    const [log] = await db
      .insert(activityLogs)
      .values({
        ...insertLog,
        timestamp: new Date()
      })
      .returning();
    
    return log;
  }

  async listActivityLogs(userId?: number, action?: string, limit: number = 100): Promise<ActivityLog[]> {
    let conditions = [];
    
    // Filter by userId if provided
    if (userId !== undefined) {
      conditions.push(eq(activityLogs.userId, userId));
    }
    
    // Filter by action if provided
    if (action) {
      conditions.push(eq(activityLogs.action, action));
    }
    
    // Combine conditions with AND if any
    const whereCondition = conditions.length > 0 
      ? and(...conditions)
      : undefined;
    
    // Query with filters and order by timestamp (newest first)
    return db
      .select()
      .from(activityLogs)
      .where(whereCondition)
      .orderBy(desc(activityLogs.timestamp))
      .limit(limit);
  }
}

// Helper function to combine conditions with OR - now replaced with sql template literals
function or(...conditions: any[]): any {
  if (conditions.length === 0) return undefined;
  if (conditions.length === 1) return conditions[0];
  
  // This function is no longer used - we now use sql template literals
  return sql`${conditions[0]} OR ${conditions[1]}`;
}