import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route } from "wouter";

interface ProtectedRouteProps {
  path: string;
  component: () => React.JSX.Element;
  requiredRole?: "admin" | "staff"; // Optional role requirement
  redirectTo?: string; // Where to redirect if role doesn't match
}

export function ProtectedRoute({
  path,
  component: Component,
  requiredRole,
  redirectTo = "/auth",
}: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();

  return (
    <Route path={path}>
      {() => {
        // Show loading state
        if (isLoading) {
          return (
            <div className="flex items-center justify-center min-h-screen">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          );
        }

        // Redirect to auth if not logged in
        if (!user) {
          return <Redirect to="/auth" />;
        }

        // Check role requirements if specified
        if (requiredRole && user.role !== requiredRole) {
          // Redirect staff to staff dashboard if they try to access admin routes
          if (user.role === "staff" && requiredRole === "admin") {
            return <Redirect to={redirectTo} />;
          }
          
          // Redirect admin to admin dashboard if they try to access staff routes
          if (user.role === "admin" && requiredRole === "staff") {
            return <Redirect to="/" />;
          }
        }

        // Render the protected component
        return <Component />;
      }}
    </Route>
  );
}
