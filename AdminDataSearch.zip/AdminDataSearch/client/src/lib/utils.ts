import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Generates a random password of specified length
 * containing uppercase, lowercase, numbers and special characters
 */
export function generatePassword(length: number = 12): string {
  const uppercaseChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ';  // removed I and O which can be confused
  const lowercaseChars = 'abcdefghijkmnopqrstuvwxyz';  // removed l which can be confused
  const numberChars = '23456789';  // removed 0 and 1 which can be confused
  const specialChars = '!@#$%^&*()_+[]{}|;:,.<>?';
  
  const allChars = uppercaseChars + lowercaseChars + numberChars + specialChars;
  
  // Ensure at least one character from each category
  let password = 
    uppercaseChars.charAt(Math.floor(Math.random() * uppercaseChars.length)) +
    lowercaseChars.charAt(Math.floor(Math.random() * lowercaseChars.length)) +
    numberChars.charAt(Math.floor(Math.random() * numberChars.length)) +
    specialChars.charAt(Math.floor(Math.random() * specialChars.length));
  
  // Fill remaining characters randomly
  for(let i = 4; i < length; i++) {
    password += allChars.charAt(Math.floor(Math.random() * allChars.length));
  }
  
  // Shuffle the password characters
  return password.split('').sort(() => 0.5 - Math.random()).join('');
}
