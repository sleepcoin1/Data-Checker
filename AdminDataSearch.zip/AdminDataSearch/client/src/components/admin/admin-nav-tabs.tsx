import { Button } from "@/components/ui/button";
import { UsersRound, Database, ClipboardList } from "lucide-react";

interface AdminNavTabsProps {
  activeTab: string;
  setActiveTab: (tab: "customers" | "staff-management" | "activity") => void;
}

export default function AdminNavTabs({ activeTab, setActiveTab }: AdminNavTabsProps) {
  return (
    <div className="border-b border-gray-200 mb-6">
      <nav className="flex space-x-8">
        <Button
          variant="link"
          className={`py-4 px-1 text-sm font-medium border-b-2 ${
            activeTab === "customers"
              ? "border-primary text-primary"
              : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
          }`}
          onClick={() => setActiveTab("customers")}
        >
          <Database className="mr-2 h-4 w-4" />
          Customer Data
        </Button>
        <Button
          variant="link"
          className={`py-4 px-1 text-sm font-medium border-b-2 ${
            activeTab === "staff-management"
              ? "border-primary text-primary"
              : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
          }`}
          onClick={() => setActiveTab("staff-management")}
        >
          <UsersRound className="mr-2 h-4 w-4" />
          Staff Management
        </Button>
        <Button
          variant="link"
          className={`py-4 px-1 text-sm font-medium border-b-2 ${
            activeTab === "activity"
              ? "border-primary text-primary"
              : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
          }`}
          onClick={() => setActiveTab("activity")}
        >
          <ClipboardList className="mr-2 h-4 w-4" />
          Activity Log
        </Button>
      </nav>
    </div>
  );
}
