import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Upload, File, Check, AlertCircle } from "lucide-react";

interface FileUploadProps {
  onSuccess?: () => void;
}

export default function FileUpload({ onSuccess }: FileUploadProps) {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  
  // Upload mutation
  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await apiRequest("POST", "/api/customers/upload", formData);
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Upload successful",
        description: data.message || `Successfully uploaded ${data.count} customers`,
      });
      
      // Reset file selection
      setFile(null);
      
      // Call success callback if provided
      if (onSuccess) {
        onSuccess();
      }
    },
    onError: (error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0] || null;
    if (selectedFile) {
      validateAndSetFile(selectedFile);
    }
  };
  
  // Handle drag events
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = () => {
    setIsDragging(false);
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFile = e.dataTransfer.files?.[0] || null;
    if (droppedFile) {
      validateAndSetFile(droppedFile);
    }
  };
  
  // Validate file type and size
  const validateAndSetFile = (file: File) => {
    // Check file type (CSV, XLSX, or TXT)
    const allowedTypes = ['text/csv', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'text/plain'];
    if (!allowedTypes.includes(file.type) && !file.name.endsWith('.csv') && !file.name.endsWith('.xlsx') && !file.name.endsWith('.txt')) {
      toast({
        title: "Invalid file type",
        description: "Please upload a CSV, XLSX, or TXT file",
        variant: "destructive",
      });
      return;
    }
    
    // Check file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "File size should not exceed 10MB",
        variant: "destructive",
      });
      return;
    }
    
    // Set file
    setFile(file);
  };
  
  // Handle file upload
  const handleUpload = () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please select a file to upload",
        variant: "destructive",
      });
      return;
    }
    
    // Create FormData and append file
    const formData = new FormData();
    formData.append("file", file);
    
    // Upload file
    uploadMutation.mutate(formData);
  };
  
  return (
    <div className="space-y-4">
      <div 
        className={`border-2 border-dashed rounded-lg p-8 text-center ${
          isDragging ? 'border-primary bg-primary/5' : 'border-gray-300'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <div className="space-y-2 cursor-pointer">
          <div className="flex justify-center">
            {file ? (
              <File className="h-12 w-12 text-primary" />
            ) : (
              <Upload className="h-12 w-12 text-gray-400" />
            )}
          </div>
          <div className="text-sm text-gray-500">
            <Label htmlFor="file-upload" className="relative cursor-pointer">
              <span className="text-primary hover:text-primary-dark">Upload a file</span>
              <Input
                id="file-upload"
                ref={fileInputRef}
                type="file"
                accept=".csv,.xlsx,.txt"
                onChange={handleFileChange}
                className="sr-only"
              />
            </Label>
            <p>or drag and drop</p>
          </div>
          <p className="text-xs text-gray-500">CSV, XLSX or TXT up to 10MB</p>
          
          {file && (
            <div className="mt-4 flex items-center justify-center text-sm">
              <Check className="h-4 w-4 text-green-500 mr-1" />
              <span className="font-medium text-gray-900">{file.name}</span>
              <span className="ml-1 text-gray-500">
                ({(file.size / 1024).toFixed(1)} KB)
              </span>
            </div>
          )}
        </div>
      </div>
      
      <div className="flex justify-end">
        <Button
          onClick={handleUpload}
          disabled={!file || uploadMutation.isPending}
          className="inline-flex items-center"
        >
          {uploadMutation.isPending ? (
            <>
              <span className="animate-spin mr-2">⟳</span>
              Processing...
            </>
          ) : (
            <>
              <Upload className="mr-2 h-4 w-4" />
              Process Upload
            </>
          )}
        </Button>
      </div>
      
      {uploadMutation.isError && (
        <div className="bg-red-50 border border-red-200 rounded p-3 text-sm text-red-800 flex items-start">
          <AlertCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium">Upload failed</p>
            <p>{uploadMutation.error.message}</p>
          </div>
        </div>
      )}
    </div>
  );
}
