import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle } from "lucide-react";

interface SearchResultProps {
  found: boolean;
  onNewSearch: () => void;
}

export default function SearchResult({ found, onNewSearch }: SearchResultProps) {
  return (
    <div id="search-result-container">
      {/* Found Result */}
      {found && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center space-y-4">
          <div className="flex justify-center">
            <CheckCircle className="h-16 w-16 text-green-500" />
          </div>
          <h3 className="text-xl font-medium text-green-800">Customer Found</h3>
          <p className="text-green-700">
            The customer information you searched for exists in our database.
          </p>
          <div className="pt-2">
            <Button 
              onClick={onNewSearch}
              className="bg-green-600 hover:bg-green-700"
            >
              New Search
            </Button>
          </div>
        </div>
      )}

      {/* Not Found Result */}
      {!found && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center space-y-4">
          <div className="flex justify-center">
            <XCircle className="h-16 w-16 text-red-500" />
          </div>
          <h3 className="text-xl font-medium text-red-800">Customer Not Found</h3>
          <p className="text-red-700">
            The customer information you searched for does not exist in our database.
          </p>
          <div className="pt-2">
            <Button 
              onClick={onNewSearch}
              className="bg-red-600 hover:bg-red-700"
            >
              New Search
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
