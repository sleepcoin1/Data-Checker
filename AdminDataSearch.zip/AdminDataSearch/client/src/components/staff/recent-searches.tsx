import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

// Define the recent search type
interface RecentSearch {
  id: number;
  query: string;
  result: string;
  timestamp: string;
}

export default function RecentSearches() {
  // Fetch recent searches
  const { data: recentSearches, isLoading } = useQuery<RecentSearch[]>({
    queryKey: ["/api/recent-searches"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });
  
  // Format timestamp
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    // If less than 1 minute ago
    if (diff < 60 * 1000) {
      return "Just now";
    }
    
    // If less than 1 hour ago
    if (diff < 60 * 60 * 1000) {
      const minutes = Math.floor(diff / (60 * 1000));
      return `${minutes} minute${minutes !== 1 ? "s" : ""} ago`;
    }
    
    // If today
    if (date.toDateString() === now.toDateString()) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) + " today";
    }
    
    // Otherwise return date and time
    return date.toLocaleDateString([], { month: "short", day: "numeric" }) + 
           " at " + date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  // If no recent searches, don't show the component
  if (!isLoading && (!recentSearches || recentSearches.length === 0)) {
    return null;
  }

  return (
    <div className="mt-8 bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200">
        <h2 className="text-base font-medium text-gray-900">Your Recent Searches</h2>
      </div>
      <div className="divide-y divide-gray-200">
        {isLoading ? (
          // Loading state
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="px-6 py-4 flex justify-between items-center">
              <div>
                <Skeleton className="h-4 w-32 mb-1" />
                <Skeleton className="h-3 w-24" />
              </div>
              <Skeleton className="h-6 w-16 rounded-full" />
            </div>
          ))
        ) : (
          // Search results
          recentSearches?.map((search) => (
            <div key={search.id} className="px-6 py-4 flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-gray-900">{search.query}</p>
                <p className="text-xs text-gray-500">{formatTimestamp(search.timestamp)}</p>
              </div>
              <Badge 
                variant={search.result === "found" ? "success" : "destructive"} 
                className="capitalize"
              >
                {search.result === "found" ? "Found" : "Not Found"}
              </Badge>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
