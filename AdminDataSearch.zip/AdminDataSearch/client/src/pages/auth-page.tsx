import { useAuth, loginSchema } from "@/hooks/use-auth";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useState, useEffect } from "react";
import { Shield, Search, LockKeyhole } from "lucide-react";
import { Redirect } from "wouter";

export default function AuthPage() {
  const { user, loginMutation } = useAuth();
  const [activeTab, setActiveTab] = useState<"admin" | "staff">("admin");

  // Redirect if already logged in
  if (user) {
    return <Redirect to={user.role === "admin" ? "/" : "/staff"} />;
  }

  // Admin login form
  const adminForm = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      remember: false
    },
  });

  // Staff login form
  const staffForm = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      remember: false
    },
  });

  // Handle admin login
  const onAdminSubmit = (data: any) => {
    const { username, password } = data;
    loginMutation.mutate({ username, password });
  };

  // Handle staff login
  const onStaffSubmit = (data: any) => {
    const { username, password } = data;
    loginMutation.mutate({ username, password });
  };

  return (
    <div className="flex min-h-screen">
      {/* Left sidebar */}
      <div className="hidden md:flex md:w-1/2 bg-primary justify-center items-center">
        <div className="max-w-md p-8 text-white">
          <h1 className="text-3xl font-bold mb-6">Customer Verification System</h1>
          <p className="mb-6">Securely search and verify customer data with role-based access control.</p>
          <div className="flex flex-col space-y-4">
            <div className="flex items-center">
              <Shield className="mr-3 h-5 w-5" />
              <span>Secure authentication</span>
            </div>
            <div className="flex items-center">
              <Search className="mr-3 h-5 w-5" />
              <span>Fast customer verification</span>
            </div>
            <div className="flex items-center">
              <LockKeyhole className="mr-3 h-5 w-5" />
              <span>Data protection controls</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - login form */}
      <div className="w-full md:w-1/2 flex items-center justify-center">
        <div className="w-full max-w-md p-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-800">Log in to your account</h2>
            <p className="text-gray-600 mt-2">Enter your credentials to access your account</p>
          </div>

          <div className="mb-6">
            <div className="flex justify-center space-x-4 mb-6">
              <button 
                className={`py-2 px-4 text-sm font-medium border-b-2 ${
                  activeTab === "admin" 
                    ? "border-primary text-primary" 
                    : "border-transparent text-gray-500 hover:text-gray-700"
                }`}
                onClick={() => setActiveTab("admin")}
              >
                Admin Login
              </button>
              <button 
                className={`py-2 px-4 text-sm font-medium border-b-2 ${
                  activeTab === "staff" 
                    ? "border-primary text-primary" 
                    : "border-transparent text-gray-500 hover:text-gray-700"
                }`}
                onClick={() => setActiveTab("staff")}
              >
                Staff Login
              </button>
            </div>

            {/* Admin Login Form */}
            {activeTab === "admin" && (
              <Form {...adminForm}>
                <form onSubmit={adminForm.handleSubmit(onAdminSubmit)} className="space-y-4">
                  <FormField
                    control={adminForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input placeholder="admin@company.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={adminForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="••••••••" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="admin-remember" />
                      <label htmlFor="admin-remember" className="text-sm text-gray-700">
                        Remember me
                      </label>
                    </div>
                    <a href="#" className="text-sm font-medium text-primary hover:text-primary-dark">
                      Forgot password?
                    </a>
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? (
                      <>
                        <span className="animate-spin mr-2">⟳</span>
                        Logging in...
                      </>
                    ) : (
                      "Log in to Admin Panel"
                    )}
                  </Button>
                </form>
              </Form>
            )}

            {/* Staff Login Form */}
            {activeTab === "staff" && (
              <Form {...staffForm}>
                <form onSubmit={staffForm.handleSubmit(onStaffSubmit)} className="space-y-4">
                  <FormField
                    control={staffForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Staff ID</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your staff ID" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={staffForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="••••••••" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex items-center">
                    <Checkbox id="staff-remember" />
                    <label htmlFor="staff-remember" className="ml-2 text-sm text-gray-700">
                      Remember me
                    </label>
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? (
                      <>
                        <span className="animate-spin mr-2">⟳</span>
                        Logging in...
                      </>
                    ) : (
                      "Log in to Staff Panel"
                    )}
                  </Button>
                </form>
              </Form>
            )}
          </div>

          <p className="text-center text-sm text-gray-600">
            By continuing, you agree to our{" "}
            <a href="#" className="text-primary hover:underline">
              Terms of Service
            </a>{" "}
            and{" "}
            <a href="#" className="text-primary hover:underline">
              Privacy Policy
            </a>
            .
          </p>
        </div>
      </div>
    </div>
  );
}
