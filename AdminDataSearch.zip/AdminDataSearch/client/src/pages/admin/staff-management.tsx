import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Search, UserPlus } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { useAuth, registerSchema } from "@/hooks/use-auth";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { generatePassword } from "@/lib/utils";

export default function StaffManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const { registerMutation } = useAuth();
  
  // Create staff form
  const form = useForm({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: generatePassword(), // Generate random password
      role: "staff", // Default to staff role
      name: "",
      email: "",
      position: "Customer Support",
    },
  });
  
  // Fetch staff members
  const { data: staffMembers, isLoading } = useQuery<User[]>({
    queryKey: ["/api/staff"],
  });

  // Filter staff based on search term
  const filteredStaff = staffMembers?.filter(staff => {
    const searchLower = searchTerm.toLowerCase();
    return (
      (staff.username && staff.username.toLowerCase().includes(searchLower)) ||
      (staff.name && staff.name.toLowerCase().includes(searchLower)) ||
      (staff.email && staff.email.toLowerCase().includes(searchLower)) ||
      (staff.staffId && staff.staffId.toLowerCase().includes(searchLower))
    );
  });
  
  // Handle form submission
  const onSubmit = (data: any) => {
    registerMutation.mutate(data, {
      onSuccess: () => {
        // Reset form after successful submission
        form.reset({
          username: "",
          password: generatePassword(), // Generate new password
          role: "staff",
          name: "",
          email: "",
          position: "Customer Support",
        });
      }
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Staff Management</CardTitle>
          <CardDescription>Manage staff accounts and access</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Staff Creation Section */}
          <div className="mb-8">
            <h3 className="text-base font-medium text-gray-900 mb-4">Create New Staff Account</h3>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Staff Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Full Name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="email@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="position"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Position</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select position" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Customer Support">Customer Support</SelectItem>
                            <SelectItem value="Sales Representative">Sales Representative</SelectItem>
                            <SelectItem value="Technical Support">Technical Support</SelectItem>
                            <SelectItem value="Manager">Manager</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="Staff username/login ID" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <div className="flex space-x-2">
                          <FormControl>
                            <Input 
                              type="text" 
                              placeholder="Auto-generated password" 
                              {...field} 
                              className="flex-1"
                            />
                          </FormControl>
                          <Button 
                            type="button" 
                            variant="outline"
                            onClick={() => form.setValue("password", generatePassword())}
                          >
                            Generate
                          </Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex justify-end mt-4">
                  <Button 
                    type="submit" 
                    disabled={registerMutation.isPending}
                    className="flex items-center"
                  >
                    {registerMutation.isPending ? (
                      <>Loading...</>
                    ) : (
                      <>
                        <UserPlus className="mr-2 h-4 w-4" />
                        Generate Staff Account
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </div>

          {/* Staff List Section */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-base font-medium text-gray-900">Staff Accounts</h3>
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search staff..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
                <Search className="h-4 w-4 absolute right-3 top-3 text-gray-400" />
              </div>
            </div>

            <div className="overflow-x-auto shadow border-b border-gray-200 sm:rounded-lg">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Position</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Active</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {isLoading ? (
                    // Loading state
                    Array(3).fill(0).map((_, i) => (
                      <tr key={i}>
                        <td className="px-6 py-4 whitespace-nowrap"><Skeleton className="h-4 w-16" /></td>
                        <td className="px-6 py-4 whitespace-nowrap"><Skeleton className="h-4 w-32" /></td>
                        <td className="px-6 py-4 whitespace-nowrap"><Skeleton className="h-4 w-40" /></td>
                        <td className="px-6 py-4 whitespace-nowrap"><Skeleton className="h-4 w-32" /></td>
                        <td className="px-6 py-4 whitespace-nowrap"><Skeleton className="h-4 w-16" /></td>
                        <td className="px-6 py-4 whitespace-nowrap"><Skeleton className="h-4 w-24" /></td>
                      </tr>
                    ))
                  ) : filteredStaff && filteredStaff.length > 0 ? (
                    // Staff data
                    filteredStaff.map((staff) => (
                      <tr key={staff.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{staff.staffId}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{staff.name || staff.username}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{staff.email || "-"}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{staff.position || "-"}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge variant={staff.active ? "success" : "destructive"}>
                            {staff.active ? "Active" : "Inactive"}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {staff.lastActive 
                            ? new Date(staff.lastActive).toLocaleString() 
                            : "Never"}
                        </td>
                      </tr>
                    ))
                  ) : (
                    // No staff or no search results
                    <tr>
                      <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                        {staffMembers?.length === 0 
                          ? "No staff accounts found. Create a staff account to get started." 
                          : "No staff found matching your search criteria."}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            {staffMembers && staffMembers.length > 0 && (
              <div className="flex items-center justify-between mt-4">
                <div className="text-sm text-gray-500">
                  Showing <span className="font-medium">{filteredStaff?.length || 0}</span> 
                  {filteredStaff?.length === 1 ? " staff member" : " staff members"}
                  {searchTerm && " (filtered)"}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
