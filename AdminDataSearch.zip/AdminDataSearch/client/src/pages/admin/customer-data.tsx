import { useQuery, useMutation } from "@tanstack/react-query";
import { Customer } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Upload } from "lucide-react";
import FileUpload from "@/components/admin/file-upload";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

export default function CustomerData() {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  
  // Fetch customers
  const { data: customers, isLoading } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });
  
  // Filter customers based on search term
  const filteredCustomers = customers?.filter(customer => {
    const searchLower = searchTerm.toLowerCase();
    return (
      (customer.username && customer.username.toLowerCase().includes(searchLower)) ||
      (customer.phoneNumber && customer.phoneNumber.toLowerCase().includes(searchLower)) ||
      (customer.telegram && customer.telegram.toLowerCase().includes(searchLower))
    );
  });
  
  // Search mutation for admin
  const searchMutation = useMutation({
    mutationFn: async (query: string) => {
      const res = await apiRequest("POST", "/api/search", { query });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.found) {
        toast({
          title: "Customer found",
          description: "The customer exists in the database.",
        });
      } else {
        toast({
          title: "Customer not found",
          description: "The customer does not exist in the database.",
          variant: "destructive",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Search failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Handle search
  const handleSearch = () => {
    if (searchTerm.trim()) {
      searchMutation.mutate(searchTerm);
    }
  };
  
  // Upload success handler - will be passed to FileUpload component
  const onUploadSuccess = () => {
    // Invalidate customers query to refresh the list
    queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
    
    toast({
      title: "Upload successful",
      description: "Customer data has been uploaded successfully.",
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Customer Data Management</CardTitle>
          <CardDescription>Upload and manage your customer database</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Upload Section */}
          <div className="mb-8">
            <h3 className="text-base font-medium text-gray-900 mb-4">Upload Customer Data</h3>
            <FileUpload onSuccess={onUploadSuccess} />
          </div>

          {/* Current Data Section */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-base font-medium text-gray-900">Current Customer Database</h3>
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search customers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="absolute right-0 top-0" 
                  onClick={handleSearch}
                >
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="overflow-x-auto shadow border-b border-gray-200 sm:rounded-lg">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Username</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone Number</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Telegram</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {isLoading ? (
                    // Loading state with skeletons
                    Array(5).fill(0).map((_, i) => (
                      <tr key={i}>
                        <td className="px-6 py-4 whitespace-nowrap"><Skeleton className="h-4 w-16" /></td>
                        <td className="px-6 py-4 whitespace-nowrap"><Skeleton className="h-4 w-32" /></td>
                        <td className="px-6 py-4 whitespace-nowrap"><Skeleton className="h-4 w-32" /></td>
                        <td className="px-6 py-4 whitespace-nowrap"><Skeleton className="h-4 w-32" /></td>
                        <td className="px-6 py-4 whitespace-nowrap"><Skeleton className="h-4 w-16" /></td>
                      </tr>
                    ))
                  ) : filteredCustomers && filteredCustomers.length > 0 ? (
                    // Customer data
                    filteredCustomers.map((customer) => (
                      <tr key={customer.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">#{customer.id}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{customer.username || "-"}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{customer.phoneNumber || "-"}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{customer.telegram || "-"}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge variant={customer.status === "active" ? "success" : "secondary"}>
                            {customer.status || "Active"}
                          </Badge>
                        </td>
                      </tr>
                    ))
                  ) : (
                    // No data or no search results
                    <tr>
                      <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                        {customers?.length === 0 
                          ? "No customer data available. Upload customer data to get started." 
                          : "No customers found matching your search criteria."}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            {customers && customers.length > 0 && (
              <div className="flex items-center justify-between mt-4">
                <div className="text-sm text-gray-500">
                  Showing <span className="font-medium">{filteredCustomers?.length || 0}</span> 
                  {filteredCustomers?.length === 1 ? " customer" : " customers"}
                  {searchTerm && " (filtered)"}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
