import { useState } from "react";
import AdminHeader from "@/components/admin/admin-header";
import AdminNavTabs from "@/components/admin/admin-nav-tabs";
import CustomerData from "@/pages/admin/customer-data";
import StaffManagement from "@/pages/admin/staff-management";
import ActivityLog from "@/pages/admin/activity-log";

// Tab type definition
type TabType = "customers" | "staff-management" | "activity";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<TabType>("customers");

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader />
      
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <AdminNavTabs activeTab={activeTab} setActiveTab={setActiveTab} />
        
        {/* Tab Content */}
        {activeTab === "customers" && <CustomerData />}
        {activeTab === "staff-management" && <StaffManagement />}
        {activeTab === "activity" && <ActivityLog />}
      </main>
    </div>
  );
}
