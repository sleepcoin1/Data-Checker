import { useQuery } from "@tanstack/react-query";
import { ActivityLog as ActivityLogType, User } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Search, LogIn, LogOut, Upload, UserPlus } from "lucide-react";

export default function ActivityLog() {
  const [dateRange, setDateRange] = useState("7days");
  const [staffFilter, setStaffFilter] = useState("all");
  const [activityType, setActivityType] = useState("all");
  
  // Fetch activity logs
  const { data: activityLogs, isLoading } = useQuery<ActivityLogType[]>({
    queryKey: ["/api/activity-logs"],
  });
  
  // Fetch staff for filter
  const { data: staffMembers } = useQuery<User[]>({
    queryKey: ["/api/staff"],
  });
  
  // Get icon for activity type
  const getActivityIcon = (action: string) => {
    switch (action) {
      case "login":
        return <LogIn className="h-5 w-5 text-gray-600" />;
      case "logout":
        return <LogOut className="h-5 w-5 text-gray-600" />;
      case "search":
        return <Search className="h-5 w-5 text-gray-600" />;
      case "upload_customers":
        return <Upload className="h-5 w-5 text-gray-600" />;
      case "create_user":
        return <UserPlus className="h-5 w-5 text-gray-600" />;
      default:
        return <Search className="h-5 w-5 text-gray-600" />;
    }
  };
  
  // Format date for display
  const formatDate = (date: string | Date | null) => {
    if (!date) return "Unknown date";
    
    const d = new Date(date);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    
    // If today, show time
    if (d.toDateString() === now.toDateString()) {
      return `${d.toLocaleTimeString()} today`;
    }
    
    // If yesterday, show "yesterday"
    if (diff < 24 * 60 * 60 * 1000 && d.getDate() === now.getDate() - 1) {
      return `${d.toLocaleTimeString()} yesterday`;
    }
    
    // Otherwise show date and time
    return d.toLocaleString();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Activity Log</CardTitle>
          <CardDescription>Monitor staff activity and system events</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Filtering Controls */}
          <div className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="activity-date-range" className="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger id="activity-date-range">
                  <SelectValue placeholder="Select date range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                  <SelectItem value="7days">Last 7 days</SelectItem>
                  <SelectItem value="30days">Last 30 days</SelectItem>
                  <SelectItem value="custom">Custom range</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label htmlFor="activity-staff" className="block text-sm font-medium text-gray-700 mb-1">Staff Member</label>
              <Select value={staffFilter} onValueChange={setStaffFilter}>
                <SelectTrigger id="activity-staff">
                  <SelectValue placeholder="Select staff member" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All staff members</SelectItem>
                  {staffMembers?.map(staff => (
                    <SelectItem key={staff.id} value={staff.id.toString()}>
                      {staff.name || staff.username} {staff.staffId ? `(${staff.staffId})` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label htmlFor="activity-type" className="block text-sm font-medium text-gray-700 mb-1">Activity Type</label>
              <Select value={activityType} onValueChange={setActivityType}>
                <SelectTrigger id="activity-type">
                  <SelectValue placeholder="Select activity type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All activities</SelectItem>
                  <SelectItem value="login">LogIn/Logout</SelectItem>
                  <SelectItem value="search">Search operations</SelectItem>
                  <SelectItem value="upload">Upload operations</SelectItem>
                  <SelectItem value="create_user">User creation</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Activity Timeline */}
          <div className="space-y-6">
            {isLoading ? (
              // Loading state
              Array(5).fill(0).map((_, i) => (
                <div key={i} className="relative pb-6">
                  <div className="flex items-start">
                    <div className="flex flex-col items-center">
                      <Skeleton className="h-9 w-9 rounded-full" />
                      <Skeleton className="h-full w-0.5 mt-1" />
                    </div>
                    <div className="ml-4 flex-1">
                      <div className="flex items-center justify-between">
                        <Skeleton className="h-4 w-40" />
                        <Skeleton className="h-4 w-24" />
                      </div>
                      <Skeleton className="h-4 w-full mt-2" />
                      <Skeleton className="h-4 w-3/4 mt-1" />
                    </div>
                  </div>
                </div>
              ))
            ) : activityLogs && activityLogs.length > 0 ? (
              // Activity logs
              activityLogs.map((log) => (
                <div key={log.id} className="relative pb-6">
                  <div className="flex items-start">
                    <div className="flex flex-col items-center">
                      <div className="h-9 w-9 rounded-full bg-gray-200 flex items-center justify-center">
                        {getActivityIcon(log.action)}
                      </div>
                      <div className="h-full w-0.5 bg-gray-200"></div>
                    </div>
                    <div className="ml-4 flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-medium text-gray-900">
                          {log.action === "login" && "User login"}
                          {log.action === "logout" && "User logout"}
                          {log.action === "search" && "Customer search performed"}
                          {log.action === "upload_customers" && "Customers uploaded"}
                          {log.action === "create_user" && "User account created"}
                        </h4>
                        <span className="text-xs text-gray-500">{formatDate(log.timestamp)}</span>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">{log.details}</p>
                      {log.action === "search" && (
                        <p className="text-sm text-gray-500 mt-1">
                          Search term: "{log.searchQuery}" - 
                          Result: {log.searchResult === "found" ? "Found" : "Not found"}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              // No activity logs
              <div className="text-center py-8 text-gray-500">
                No activity logs found. Activity will be recorded here when users perform actions.
              </div>
            )}
            
            {activityLogs && activityLogs.length > 50 && (
              <div className="flex justify-center">
                <Button 
                  variant="link"
                  className="text-primary hover:text-primary-dark font-medium"
                >
                  Load More Activity
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
