import { useState } from "react";
import StaffHeader from "@/components/staff/staff-header";
import SearchForm from "@/components/staff/search-form";
import SearchResult from "@/components/staff/search-result";
import RecentSearches from "@/components/staff/recent-searches";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function StaffDashboard() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchPerformed, setSearchPerformed] = useState(false);
  const [searchResult, setSearchResult] = useState<boolean | null>(null);
  const { toast } = useToast();
  
  // Search mutation
  const searchMutation = useMutation({
    mutationFn: async (query: string) => {
      const res = await apiRequest("POST", "/api/search", { query });
      return res.json();
    },
    onSuccess: (data) => {
      setSearchResult(data.found);
      setSearchPerformed(true);
    },
    onError: (error) => {
      toast({
        title: "Search failed",
        description: error.message,
        variant: "destructive",
      });
      setSearchPerformed(false);
      setSearchResult(null);
    }
  });
  
  // Handle search
  const handleSearch = (query: string) => {
    setSearchQuery(query);
    
    if (query.trim()) {
      searchMutation.mutate(query);
    } else {
      toast({
        title: "Empty search",
        description: "Please enter a search term",
        variant: "destructive",
      });
    }
  };
  
  // Reset search
  const resetSearch = () => {
    setSearchPerformed(false);
    setSearchResult(null);
    setSearchQuery("");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <StaffHeader />
      
      <main className="max-w-3xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="px-6 py-5 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-900">Customer Verification Tool</h2>
            <p className="mt-1 text-sm text-gray-500">Search for customers by username, phone number, or Telegram handle</p>
          </div>
          <div className="p-6">
            {/* Search Form */}
            {!searchPerformed && (
              <SearchForm 
                onSearch={handleSearch} 
                isLoading={searchMutation.isPending} 
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
              />
            )}
            
            {/* Search Results */}
            {searchPerformed && searchResult !== null && (
              <SearchResult 
                found={searchResult} 
                onNewSearch={resetSearch} 
              />
            )}
            
            {/* Help/Instructions */}
            {!searchPerformed && (
              <div className="mt-8 border-t border-gray-200 pt-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Search Instructions</h3>
                <ul className="text-sm text-gray-500 space-y-2">
                  <li className="flex items-start">
                    <span className="text-gray-400 mr-2 text-sm">•</span>
                    <span>Enter a username, phone number, or Telegram handle to verify if the customer exists in our database.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-gray-400 mr-2 text-sm">•</span>
                    <span>For phone numbers, include the country code (e.g., +1 555-123-4567).</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-gray-400 mr-2 text-sm">•</span>
                    <span>For Telegram handles, include the @ symbol (e.g., @username).</span>
                  </li>
                </ul>
              </div>
            )}
          </div>
        </div>
        
        {/* Recent Searches */}
        <RecentSearches />
      </main>
    </div>
  );
}
